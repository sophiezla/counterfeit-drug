# PharmaChecked License Review — 2026-09-07

This review distinguishes source evidence from image redistribution rights.

## FDA-hosted images
FDA states that, unless otherwise noted, the contents of the FDA website, including text and graphics, are public domain. Each FDA-hosted image is therefore marked `public_domain` for rights review, with an explicit requirement to check for any per-image third-party attribution or exception before final publication.

## WHO-hosted images
WHO states that its copyrighted material is not automatically reusable. Materials under CC BY-NC-SA 3.0 IGO can be reused for non-commercial purposes under the license. Other WHO material, including photos/figures, may require permission, and third-party credited material is not covered by WHO's own license. Existing WHO image records are therefore `metadata_only_permission_required` unless an image-level license or written permission is separately documented.

## Replenishment
The replacement registry contains public-domain Wikimedia Commons records derived from U.S. government/FDA photography and other candidates. Only records with both (1) individual rights evidence and (2) authoritative case evidence should enter the primary supervised dataset. Mixed comparison photographs must be segmented before binary labeling.

## Publication rule
No image bytes are represented as redistributed unless the exact image has been downloaded, hashed, checked for duplicates, and its rights evidence stored alongside the metadata.
