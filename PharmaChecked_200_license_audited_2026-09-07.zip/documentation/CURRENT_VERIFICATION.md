# Current-source verification — 2026-09-07

- FDA current Counterfeit Medicine index lists counterfeit Ozempic, alli, Botox, Ozempic pen, and Muro 128 reports.
- FDA current website policy says FDA website contents, including graphics, are public domain unless otherwise noted.
- WHO current medical-product-alert index lists 2026 DARZALEX and JAKAVI falsified-product alerts and the 2026 ACCUPAQUE/OMNIPAQUE/VISIPAQUE alert.
- WHO Medical Product Alert N°1/2026 is **substandard**, not falsified. CASE_0033 has been corrected to `UNVERIFIED` in this revision.
- Current WHO falsified alerts reviewed include IBRANCE (2025), SIMULECT (2025), IMFINZI (2025/2024), JAKAVI (2026), and DARZALEX (2026), all with explicit falsification statements/confirmation.

## Rights conclusion

FDA-hosted image references are marked `public_domain` for rights review on the basis of FDA's current website policy, subject to checking individual third-party credits/exceptions. WHO-hosted image references remain metadata-only pending image-level permission or an applicable open license.

## Publication gate

The 200 records are a rights-audited candidate manifest, **not 200 redistributable image files**. Remaining gates are actual image retrieval, per-image rights evidence, SHA-256/pHash, dimensions, duplicate review, exact alert URLs, and two-person annotation/adjudication.
