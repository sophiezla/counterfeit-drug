# Rights-audited 200-record PharmaChecked collection

Audit date: 2026-09-07

The original 200-record collection was a candidate/provenance manifest, not a completed image dataset. This revision adds explicit image-level rights status.

The manifest contains 27 FDA direct image references, 30 WHO direct image references, and 143 source-photo queue records. FDA references are marked public-domain on the basis of FDA's current website policy, subject to checking any individual exception. WHO references are kept metadata-only pending image-level permission or an applicable open license. Queue records remain unlicensed until a concrete image is selected.

This package does not claim that 200 image files are legally redistributable. It provides the rights audit and a replenishment registry so the final public dataset can be built without silently treating public visibility as permission.
